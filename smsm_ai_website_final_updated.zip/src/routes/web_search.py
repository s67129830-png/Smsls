from flask import Blueprint, request, jsonify
import requests
from bs4 import BeautifulSoup
import re
import time
import urllib.parse
import random

web_search_bp = Blueprint('web_search', __name__)

def get_random_user_agent():
    """الحصول على User-Agent عشوائي لتجنب الحظر"""
    user_agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/91.0.864.59',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    ]
    return random.choice(user_agents)

def clean_text(text):
    """تنظيف النص من العلامات والمسافات الزائدة"""
    if not text:
        return ""
    # إزالة العلامات HTML
    text = re.sub(r'<[^>]+>', '', text)
    # إزالة المسافات الزائدة
    text = re.sub(r'\s+', ' ', text)
    # إزالة الأسطر الفارغة
    text = re.sub(r'\n\s*\n', '\n', text)
    return text.strip()

def search_duckduckgo_html(query, max_results=10):
    """البحث في DuckDuckGo عبر HTML scraping"""
    try:
        # تشفير الاستعلام
        encoded_query = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded_query}"
        
        headers = {
            'User-Agent': get_random_user_agent(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ar,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        results = []
        
        # البحث عن النتائج في DuckDuckGo
        result_divs = soup.find_all('div', class_='result')
        
        for div in result_divs[:max_results]:
            try:
                # العنوان والرابط
                title_link = div.find('a', class_='result__a')
                if not title_link:
                    continue
                    
                title = clean_text(title_link.get_text())
                link = title_link.get('href', '')
                
                # الوصف
                snippet_div = div.find('a', class_='result__snippet')
                snippet = clean_text(snippet_div.get_text()) if snippet_div else ""
                
                if title and link:
                    results.append({
                        'title': title,
                        'url': link,
                        'snippet': snippet,
                        'source': 'DuckDuckGo'
                    })
                    
            except Exception as e:
                print(f"خطأ في معالجة نتيجة DuckDuckGo: {e}")
                continue
        
        return results
        
    except Exception as e:
        print(f"خطأ في البحث في DuckDuckGo: {e}")
        return []

def search_bing(query, max_results=10):
    """البحث في Bing عبر HTML scraping"""
    try:
        # تشفير الاستعلام
        encoded_query = urllib.parse.quote_plus(query)
        url = f"https://www.bing.com/search?q={encoded_query}"
        
        headers = {
            'User-Agent': get_random_user_agent(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ar,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        results = []
        
        # البحث عن النتائج في Bing
        result_divs = soup.find_all('li', class_='b_algo')
        
        for div in result_divs[:max_results]:
            try:
                # العنوان والرابط
                title_link = div.find('h2').find('a') if div.find('h2') else None
                if not title_link:
                    continue
                    
                title = clean_text(title_link.get_text())
                link = title_link.get('href', '')
                
                # الوصف
                snippet_div = div.find('p') or div.find('div', class_='b_caption')
                snippet = clean_text(snippet_div.get_text()) if snippet_div else ""
                
                if title and link:
                    results.append({
                        'title': title,
                        'url': link,
                        'snippet': snippet,
                        'source': 'Bing'
                    })
                    
            except Exception as e:
                print(f"خطأ في معالجة نتيجة Bing: {e}")
                continue
        
        return results
        
    except Exception as e:
        print(f"خطأ في البحث في Bing: {e}")
        return []

def search_startpage(query, max_results=10):
    """البحث في Startpage عبر HTML scraping"""
    try:
        # تشفير الاستعلام
        encoded_query = urllib.parse.quote_plus(query)
        url = f"https://www.startpage.com/sp/search?query={encoded_query}"
        
        headers = {
            'User-Agent': get_random_user_agent(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ar,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        results = []
        
        # البحث عن النتائج في Startpage
        result_divs = soup.find_all('div', class_='w-gl__result')
        
        for div in result_divs[:max_results]:
            try:
                # العنوان والرابط
                title_link = div.find('a', class_='w-gl__result-title')
                if not title_link:
                    continue
                    
                title = clean_text(title_link.get_text())
                link = title_link.get('href', '')
                
                # الوصف
                snippet_div = div.find('p', class_='w-gl__description')
                snippet = clean_text(snippet_div.get_text()) if snippet_div else ""
                
                if title and link:
                    results.append({
                        'title': title,
                        'url': link,
                        'snippet': snippet,
                        'source': 'Startpage'
                    })
                    
            except Exception as e:
                print(f"خطأ في معالجة نتيجة Startpage: {e}")
                continue
        
        return results
        
    except Exception as e:
        print(f"خطأ في البحث في Startpage: {e}")
        return []

def search_wikipedia(query):
    """البحث في ويكيبيديا"""
    try:
        # البحث في ويكيبيديا العربية أولاً
        search_url = f"https://ar.wikipedia.org/api/rest_v1/page/summary/{urllib.parse.quote(query)}"
        headers = {
            'User-Agent': get_random_user_agent()
        }
        
        response = requests.get(search_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            return [{
                'title': data.get('title', ''),
                'snippet': data.get('extract', ''),
                'url': data.get('content_urls', {}).get('desktop', {}).get('page', ''),
                'source': 'ويكيبيديا العربية'
            }]
        
        # إذا لم تنجح العربية، جرب الإنجليزية
        search_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{urllib.parse.quote(query)}"
        response = requests.get(search_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            return [{
                'title': data.get('title', ''),
                'snippet': data.get('extract', ''),
                'url': data.get('content_urls', {}).get('desktop', {}).get('page', ''),
                'source': 'Wikipedia English'
            }]
            
    except Exception as e:
        print(f"خطأ في البحث في ويكيبيديا: {e}")
    
    return []

def summarize_results(results, query, max_sentences=5):
    """تلخيص النتائج"""
    if not results:
        return f'عذراً، لم أتمكن من العثور على معلومات حول "{query}". يرجى المحاولة بكلمات مختلفة.'
    
    # تجميع النصوص
    combined_text = ' '.join([result['snippet'] for result in results if result['snippet']])
    
    if not combined_text:
        return f'وجدت نتائج حول "{query}" ولكن لا توجد تفاصيل كافية للتلخيص.'
    
    # تقسيم النص إلى جمل
    sentences = re.split(r'[.!?]+\s*', combined_text)
    sentences = [s.strip() for s in sentences if s.strip() and len(s.strip()) > 10]

    if not sentences:
        return f'وجدت نتائج حول "{query}" ولكن لا توجد معلومات واضحة للتلخيص.'

    # تسجيل الجمل حسب الصلة بالاستعلام
    query_keywords = set(query.lower().split())
    scored_sentences = []

    for i, sentence in enumerate(sentences):
        score = 0
        # زيادة النقاط للجمل التي تحتوي على كلمات مفتاحية من الاستعلام
        for keyword in query_keywords:
            if keyword in sentence.lower():
                score += 1
        # إعطاء الأولوية للجمل الأولى
        score += (len(sentences) - i) / len(sentences)
        scored_sentences.append((score, sentence))

    # ترتيب الجمل حسب النقاط تنازلياً
    scored_sentences.sort(key=lambda x: x[0], reverse=True)

    # اختيار أفضل الجمل
    summary_sentences = [s[1] for s in scored_sentences[:max_sentences]]

    # إعادة ترتيب الجمل المختارة حسب ترتيبها الأصلي في النص
    original_order_summary = []
    for original_sentence in sentences:
        if original_sentence in summary_sentences:
            original_order_summary.append(original_sentence)
            summary_sentences.remove(original_sentence)

    return '. '.join(original_order_summary) + '.'

@web_search_bp.route('/web-search', methods=['POST'])
def web_search():
    """نقطة نهاية البحث على الويب"""
    try:
        data = request.get_json()
        query = data.get('query', '').strip()
        
        if not query:
            return jsonify({'error': 'يرجى إدخال استعلام البحث'}), 400
        
        print(f"البحث عن: {query}")
        
        # البحث في مصادر متعددة
        all_results = []
        
        # البحث في ويكيبيديا أولاً
        wiki_results = search_wikipedia(query)
        all_results.extend(wiki_results)
        
        # البحث في DuckDuckGo
        ddg_results = search_duckduckgo_html(query, max_results=5)
        all_results.extend(ddg_results)
        
        # البحث في Bing
        bing_results = search_bing(query, max_results=5)
        all_results.extend(bing_results)
        
        # البحث في Startpage
        startpage_results = search_startpage(query, max_results=3)
        all_results.extend(startpage_results)
        
        # إزالة النتائج المكررة
        unique_results = []
        seen_urls = set()
        
        for result in all_results:
            if result['url'] and result['url'] not in seen_urls:
                seen_urls.add(result['url'])
                unique_results.append(result)
        
        # تلخيص النتائج
        summary = summarize_results(unique_results, query)
        
        # إعداد المصادر
        sources = []
        for result in unique_results[:10]:  # أخذ أول 10 نتائج فقط
            if result["title"] and result["snippet"]:
                sources.append({
                    "title": result["title"],
                    "snippet": result["snippet"][:200] + "..." if len(result["snippet"]) > 200 else result["snippet"],
                    "url": result["url"],
                    "source": result["source"]
                })
        
        return jsonify({
            "query": query,
            "summary": summary,
            "results": unique_results[:8],  # أول 8 نتائج مفصلة
            "sources": sources,
            "total_results": len(unique_results)
        })
        
    except Exception as e:
        print(f"خطأ في معالجة البحث: {e}")
        return jsonify({'error': 'حدث خطأ أثناء البحث على الويب'}), 500

@web_search_bp.route('/health', methods=['GET'])
def health():
    """فحص صحة الخدمة"""
    return jsonify({'status': 'healthy', 'service': 'SMSM AI Web Search'})

