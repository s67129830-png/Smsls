from flask import Blueprint, request, jsonify
import requests
from bs4 import BeautifulSoup
import re
import time

search_bp = Blueprint('search', __name__)

def clean_text(text):
    """تنظيف النص من العلامات والمسافات الزائدة"""
    # إزالة العلامات HTML
    text = re.sub(r'<[^>]+>', '', text)
    # إزالة المسافات الزائدة
    text = re.sub(r'\s+', ' ', text)
    # إزالة الأسطر الفارغة
    text = re.sub(r'\n\s*\n', '\n', text)
    return text.strip()

def summarize_text(text, query, max_sentences=5):
    """تلخيص النص إلى عدد محدد من الجمل، مع إعطاء الأولوية للجمل التي تحتوي على كلمات مفتاحية من الاستعلام"""
    sentences = re.split(r'[.!?]+\s*', text)
    sentences = [s.strip() for s in sentences if s.strip()]

    if not sentences:
        return ""

    query_keywords = set(query.lower().split())
    scored_sentences = []

    for i, sentence in enumerate(sentences):
        score = 0
        # زيادة النقاط للجمل التي تحتوي على كلمات مفتاحية من الاستعلام
        for keyword in query_keywords:
            if keyword in sentence.lower():
                score += 1
        # إعطاء الأولوية للجمل الأولى
        score += (len(sentences) - i) / len(sentences) # جملة أقدم = نقاط أعلى
        scored_sentences.append((score, sentence))

    # ترتيب الجمل حسب النقاط تنازلياً
    scored_sentences.sort(key=lambda x: x[0], reverse=True)

    # اختيار أفضل الجمل
    summary_sentences = [s[1] for s in scored_sentences[:max_sentences]]

    # إعادة ترتيب الجمل المختارة حسب ترتيبها الأصلي في النص
    original_order_summary = []
    for original_sentence in sentences:
        if original_sentence in summary_sentences:
            original_order_summary.append(original_sentence)
            summary_sentences.remove(original_sentence) # إزالة الجملة لتجنب التكرار

    return '. '.join(original_order_summary) + '.'

def search_duckduckgo(query):
    """البحث باستخدام DuckDuckGo"""
    try:
        # استخدام DuckDuckGo Instant Answer API
        url = f"https://api.duckduckgo.com/?q={query}&format=json&no_html=1&skip_disambig=1"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        data = response.json()
        
        results = []
        
        # الحصول على الإجابة المباشرة
        if data.get('Abstract'):
            results.append({
                'title': data.get('AbstractText', 'معلومات عامة'),
                'snippet': data.get('Abstract'),
                'url': data.get('AbstractURL', ''),
                'source': 'DuckDuckGo Instant Answer'
            })
        
        # الحصول على النتائج ذات الصلة
        if data.get('RelatedTopics'):
            for topic in data.get("RelatedTopics", [])[:5]:
                if isinstance(topic, dict) and topic.get('Text'):
                    results.append({
                        'title': topic.get('Text', '')[:100] + '...',
                        'snippet': topic.get('Text', ''),
                        'url': topic.get('FirstURL', ''),
                        'source': 'DuckDuckGo Related'
                    })
        
        return results
        
    except Exception as e:
        print(f"خطأ في البحث: {e}")
        return []

def search_wikipedia(query):
    """البحث في ويكيبيديا العربية"""
    try:
        # البحث في ويكيبيديا العربية
        search_url = f"https://ar.wikipedia.org/api/rest_v1/page/summary/{query}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(search_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            return [{
                'title': data.get('title', ''),
                'snippet': data.get('extract', ''),
                'url': data.get('content_urls', {}).get('desktop', {}).get('page', ''),
                'source': 'ويكيبيديا العربية'
            }]
        
        # إذا لم تنجح العربية، جرب الإنجليزية
        search_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{query}"
        response = requests.get(search_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            return [{
                'title': data.get('title', ''),
                'snippet': data.get('extract', ''),
                'url': data.get('content_urls', {}).get('desktop', {}).get('page', ''),
                'source': 'Wikipedia English'
            }]
            
    except Exception as e:
        print(f"خطأ في البحث في ويكيبيديا: {e}")
    
    return []

@search_bp.route('/search', methods=['POST'])
def search():
    """نقطة نهاية البحث والتلخيص"""
    try:
        data = request.get_json()
        query = data.get('query', '').strip()
        
        if not query:
            return jsonify({'error': 'يرجى إدخال استعلام البحث'}), 400
        
        # البحث في مصادر متعددة
        all_results = []
        
        # البحث في ويكيبيديا أولاً
        wiki_results = search_wikipedia(query)
        all_results.extend(wiki_results)
        
        # البحث في DuckDuckGo
        ddg_results = search_duckduckgo(query)
        all_results.extend(ddg_results)
        
        if not all_results:
            return jsonify({
                'query': query,
                'summary': f'عذراً، لم أتمكن من العثور على معلومات حول "{query}". يرجى المحاولة بكلمات مختلفة.',
                'results': [],
                'sources': []
            })
        
        # تجميع النصوص للتلخيص
        combined_text = ' '.join([result['snippet'] for result in all_results if result['snippet']])
        
        # تلخيص النتائج
        summary = summarize_text(combined_text, query, max_sentences=5)        
        # إعداد المصادر
        sources = []
        for result in all_results[:7]:  # أخذ أول 7 نتائج فقط
            if result["title"] and result["snippet"]:
                sources.append({
                    "title": result["title"],
                    "snippet": result["snippet"][:200] + "..." if len(result["snippet"]) > 200 else result["snippet"],
                    "url": result["url"],
                    "source": result["source"]
                })
        
        return jsonify({
            "query": query,
            "summary": summary,
            "results": all_results[:5],  # أول 5 نتائج مفصلة
            "sources": sources
        })
        
    except Exception as e:
        print(f"خطأ في معالجة البحث: {e}")
        return jsonify({'error': 'حدث خطأ أثناء البحث'}), 500

@search_bp.route('/health', methods=['GET'])
def health():
    """فحص صحة الخدمة"""
    return jsonify({'status': 'healthy', 'service': 'SMSM AI Search'})

