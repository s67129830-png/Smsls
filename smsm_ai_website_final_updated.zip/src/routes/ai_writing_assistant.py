from flask import Blueprint, request, jsonify
import openai
import os
import re
import json

ai_writing_bp = Blueprint('ai_writing', __name__)

# إعداد OpenAI
openai.api_key = os.getenv('OPENAI_API_KEY')
openai.api_base = os.getenv('OPENAI_API_BASE')

class WritingStyleAnalyzer:
    """محلل أساليب الكتابة"""
    
    def __init__(self):
        self.arabic_writing_prompts = {
            "formal": "اكتب بأسلوب رسمي وأكاديمي، استخدم مفردات فصيحة وجمل مترابطة ومنطقية.",
            "creative": "اكتب بأسلوب إبداعي وأدبي، استخدم الصور البلاغية والتشبيهات والاستعارات.",
            "simple": "اكتب بأسلوب بسيط وواضح، استخدم جمل قصيرة ومفردات سهلة الفهم.",
            "persuasive": "اكتب بأسلوب إقناعي ومؤثر، استخدم الحجج القوية والأدلة المنطقية.",
            "narrative": "اكتب بأسلوب سردي وقصصي، استخدم التسلسل الزمني والوصف التفصيلي.",
            "expository": "اكتب بأسلوب تفسيري وتوضيحي، ركز على شرح المفاهيم والأفكار بوضوح."
        }
    
    def extract_writing_style(self, text_samples):
        """استخراج أسلوب الكتابة من عينات النصوص"""
        try:
            combined_text = "\n\n".join(text_samples)
            
            prompt = f"""
            قم بتحليل الأسلوب الكتابي للنصوص التالية وقدم وصفاً مفصلاً للخصائص الأسلوبية:

            النصوص:
            {combined_text}

            يرجى تحليل:
            1. النبرة العامة (رسمية، ودية، أكاديمية، إبداعية)
            2. طول الجمل وتعقيدها
            3. نوع المفردات المستخدمة
            4. أسلوب التنظيم والهيكلة
            5. استخدام الأدوات البلاغية
            6. طريقة مخاطبة القارئ

            قدم الوصف بشكل مفصل ليمكن استخدامه لإعادة إنتاج نفس الأسلوب.
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.3
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            print(f"خطأ في استخراج الأسلوب: {e}")
            return None

class EnhancedWritingAssistant:
    """مساعد الكتابة المحسن"""
    
    def __init__(self):
        self.style_analyzer = WritingStyleAnalyzer()
        
    def improve_expression(self, text, style="formal", focus_areas=None):
        """تحسين التعبير الكتابي"""
        try:
            if focus_areas is None:
                focus_areas = ["grammar", "clarity", "flow", "vocabulary"]
            
            style_instruction = self.style_analyzer.arabic_writing_prompts.get(style, 
                self.style_analyzer.arabic_writing_prompts["formal"])
            
            focus_instructions = {
                "grammar": "صحح الأخطاء النحوية والإملائية",
                "clarity": "حسن وضوح المعنى والفكرة",
                "flow": "حسن تدفق الأفكار والانتقال بين الجمل",
                "vocabulary": "استخدم مفردات أكثر دقة وتنوعاً",
                "structure": "حسن تنظيم وهيكلة النص",
                "coherence": "عزز التماسك والترابط بين الأفكار"
            }
            
            selected_focuses = [focus_instructions[area] for area in focus_areas if area in focus_instructions]
            focus_text = "، ".join(selected_focuses)
            
            prompt = f"""
            أنت مساعد كتابة خبير في اللغة العربية. مهمتك تحسين النص التالي:

            النص الأصلي:
            {text}

            التعليمات:
            1. {style_instruction}
            2. {focus_text}
            3. احتفظ بالمعنى الأصلي والأفكار الرئيسية
            4. قدم نسخة محسنة من النص
            5. اشرح التحسينات التي أجريتها

            قدم الإجابة في تنسيق JSON:
            {{
                "improved_text": "النص المحسن",
                "improvements": ["قائمة بالتحسينات المطبقة"],
                "style_applied": "الأسلوب المطبق",
                "suggestions": ["اقتراحات إضافية للتحسين"]
            }}
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1500,
                temperature=0.3
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            print(f"خطأ في تحسين التعبير: {e}")
            return None
    
    def generate_essay(self, topic, style="formal", length="medium", requirements=None):
        """توليد تعبير كامل حول موضوع معين"""
        try:
            if requirements is None:
                requirements = []
            
            length_instructions = {
                "short": "اكتب تعبيراً قصيراً (200-300 كلمة)",
                "medium": "اكتب تعبيراً متوسط الطول (400-600 كلمة)", 
                "long": "اكتب تعبيراً طويلاً ومفصلاً (700-1000 كلمة)"
            }
            
            style_instruction = self.style_analyzer.arabic_writing_prompts.get(style,
                self.style_analyzer.arabic_writing_prompts["formal"])
            
            length_instruction = length_instructions.get(length, length_instructions["medium"])
            
            requirements_text = ""
            if requirements:
                requirements_text = f"متطلبات إضافية: {', '.join(requirements)}"
            
            prompt = f"""
            اكتب تعبيراً باللغة العربية حول الموضوع التالي:

            الموضوع: {topic}

            التعليمات:
            1. {style_instruction}
            2. {length_instruction}
            3. {requirements_text}
            4. اتبع هيكلة واضحة: مقدمة، عرض، خاتمة
            5. استخدم أمثلة وشواهد مناسبة
            6. اجعل النص متماسكاً ومترابطاً

            قدم الإجابة في تنسيق JSON:
            {{
                "title": "عنوان مناسب للتعبير",
                "essay": "نص التعبير كاملاً",
                "structure": {{
                    "introduction": "المقدمة",
                    "body": "العرض",
                    "conclusion": "الخاتمة"
                }},
                "word_count": "عدد الكلمات التقريبي",
                "style_used": "الأسلوب المستخدم"
            }}
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=2000,
                temperature=0.7
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            print(f"خطأ في توليد التعبير: {e}")
            return None
    
    def analyze_text_quality(self, text):
        """تحليل جودة النص وتقديم تقييم مفصل"""
        try:
            prompt = f"""
            قم بتحليل النص التالي وتقييم جودته من عدة جوانب:

            النص:
            {text}

            يرجى تقييم:
            1. الصحة النحوية والإملائية (من 10)
            2. وضوح المعنى والأفكار (من 10)
            3. تدفق وترابط الأفكار (من 10)
            4. ثراء المفردات (من 10)
            5. قوة الأسلوب (من 10)
            6. التنظيم والهيكلة (من 10)

            قدم الإجابة في تنسيق JSON:
            {{
                "overall_score": "الدرجة الإجمالية من 60",
                "detailed_scores": {{
                    "grammar": "درجة النحو من 10",
                    "clarity": "درجة الوضوح من 10",
                    "flow": "درجة التدفق من 10",
                    "vocabulary": "درجة المفردات من 10",
                    "style": "درجة الأسلوب من 10",
                    "structure": "درجة التنظيم من 10"
                }},
                "strengths": ["نقاط القوة"],
                "weaknesses": ["نقاط الضعف"],
                "recommendations": ["توصيات للتحسين"]
            }}
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.3
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            print(f"خطأ في تحليل جودة النص: {e}")
            return None

# إنشاء مثيل من المساعد
writing_assistant = EnhancedWritingAssistant()

@ai_writing_bp.route('/improve-text', methods=['POST'])
def improve_text():
    """تحسين نص موجود"""
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        style = data.get('style', 'formal')
        focus_areas = data.get('focus_areas', ["grammar", "clarity", "flow"])
        
        if not text:
            return jsonify({'error': 'يرجى إدخال النص المراد تحسينه'}), 400
        
        result = writing_assistant.improve_expression(text, style, focus_areas)
        
        if result:
            return jsonify({
                'success': True,
                'original_text': text,
                'improved_text': result.get('improved_text'),
                'improvements': result.get('improvements'),
                'style_applied': result.get('style_applied'),
                'suggestions': result.get('suggestions')
            })
        else:
            return jsonify({'error': 'فشل في تحسين النص'}), 500
            
    except Exception as e:
        print(f"خطأ في تحسين النص: {e}")
        return jsonify({'error': 'حدث خطأ أثناء معالجة الطلب'}), 500

@ai_writing_bp.route('/generate-essay', methods=['POST'])
def generate_essay():
    """توليد تعبير جديد"""
    try:
        data = request.get_json()
        topic = data.get('topic', '').strip()
        style = data.get('style', 'formal')
        length = data.get('length', 'medium')
        requirements = data.get('requirements', [])
        
        if not topic:
            return jsonify({'error': 'يرجى إدخال موضوع التعبير'}), 400
        
        result = writing_assistant.generate_essay(topic, style, length, requirements)
        
        if result:
            return jsonify({
                'success': True,
                'topic': topic,
                'title': result.get('title'),
                'essay': result.get('essay'),
                'structure': result.get('structure'),
                'word_count': result.get('word_count'),
                'style_used': result.get('style_used')
            })
        else:
            return jsonify({'error': 'فشل في توليد التعبير'}), 500
            
    except Exception as e:
        print(f"خطأ في توليد التعبير: {e}")
        return jsonify({'error': 'حدث خطأ أثناء معالجة الطلب'}), 500

@ai_writing_bp.route('/analyze-text', methods=['POST'])
def analyze_text():
    """تحليل جودة النص"""
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        
        if not text:
            return jsonify({'error': 'يرجى إدخال النص المراد تحليله'}), 400
        
        result = writing_assistant.analyze_text_quality(text)
        
        if result:
            return jsonify({
                'success': True,
                'text': text,
                'analysis': result
            })
        else:
            return jsonify({'error': 'فشل في تحليل النص'}), 500
            
    except Exception as e:
        print(f"خطأ في تحليل النص: {e}")
        return jsonify({'error': 'حدث خطأ أثناء معالجة الطلب'}), 500

@ai_writing_bp.route('/extract-style', methods=['POST'])
def extract_style():
    """استخراج أسلوب الكتابة من عينات"""
    try:
        data = request.get_json()
        text_samples = data.get('text_samples', [])
        
        if not text_samples or len(text_samples) == 0:
            return jsonify({'error': 'يرجى إدخال عينات النصوص'}), 400
        
        style_analyzer = WritingStyleAnalyzer()
        result = style_analyzer.extract_writing_style(text_samples)
        
        if result:
            return jsonify({
                'success': True,
                'samples_count': len(text_samples),
                'style_description': result
            })
        else:
            return jsonify({'error': 'فشل في استخراج الأسلوب'}), 500
            
    except Exception as e:
        print(f"خطأ في استخراج الأسلوب: {e}")
        return jsonify({'error': 'حدث خطأ أثناء معالجة الطلب'}), 500

@ai_writing_bp.route('/writing-styles', methods=['GET'])
def get_writing_styles():
    """الحصول على قائمة بأساليب الكتابة المتاحة"""
    styles = {
        "formal": "رسمي وأكاديمي",
        "creative": "إبداعي وأدبي", 
        "simple": "بسيط وواضح",
        "persuasive": "إقناعي ومؤثر",
        "narrative": "سردي وقصصي",
        "expository": "تفسيري وتوضيحي"
    }
    
    return jsonify({
        'success': True,
        'styles': styles
    })

@ai_writing_bp.route('/health', methods=['GET'])
def health():
    """فحص صحة خدمة مساعد الكتابة"""
    return jsonify({'status': 'healthy', 'service': 'AI Writing Assistant'})

